<section class="info-empresa">
	<div class="container">
		<center><h2>Correo enviado exitosamente.</h2></center>
	</div>
</section>

<script type="text/javascript">
	function redireccionarPagina() {
  window.location = "/proyectowe";
}
setTimeout("redireccionarPagina()", 3000);
</script>