
<!DOCTYPE doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <link crossorigin="anonymous" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" rel="stylesheet">
  <link href="<?php echo BASE_URL?>views/assets/css/login.css" rel="stylesheet" type="text/css">
  <link rel="stylesheet" type="text/css" href="<?php echo BASE_URL?>views/assets/open-ionic/font/css/open-iconic-bootstrap.css">
  <title>
    Login proyecto web
  </title>
</head>
<body>
