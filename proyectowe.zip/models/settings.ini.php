<?php return;?> ;
[basedatos]
driver="mysql"
host="localhost"
port="3306"
user="root"
pass=""
dbname="proyecto_web"
charset="utf8"
